//
//  QustionModal.m
//  QustionList
//
//  Created by WinterLin on 15/12/28.
//  Copyright © 2015年 WinterLin. All rights reserved.
//

#import "QuestionModal.h"

@implementation QuestionModal

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _questionName = @"";
        _questionContext = @"";
    }
    return self;
}
@end
