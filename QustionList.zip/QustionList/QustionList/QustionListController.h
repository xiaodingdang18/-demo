//
//  QustionListController.h
//  QustionList
//
//  Created by WinterLin on 15/12/28.
//  Copyright © 2015年 WinterLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QustionListController : UITableViewController

@property (copy, nonatomic) NSString *questionKu;
@end
