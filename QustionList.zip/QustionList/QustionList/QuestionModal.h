//
//  QustionModal.h
//  QustionList
//
//  Created by WinterLin on 15/12/28.
//  Copyright © 2015年 WinterLin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QuestionModal : NSObject

@property (nonatomic, copy) NSString *questionName;
@property (nonatomic, copy) NSString *questionContext;
@end
